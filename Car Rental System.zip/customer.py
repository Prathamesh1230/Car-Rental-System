class Customer:
    def __init__(self, customer_id, name, license_number):
        self.customer_id = customer_id
        self.name = name
        self.license_number = license_number
